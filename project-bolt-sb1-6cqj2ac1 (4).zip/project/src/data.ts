import { Truck, TrendingUp, Calculator, ShieldCheck, Zap } from 'lucide-react';

export const COURSES = [
  {
    icon: Truck,
    title: 'Truck Dispatching',
    duration: '30 Days',
    fee: '₹30,000',
    topics: ['Load Booking', 'Carrier Setup', 'Driver Management', 'Route Planning', 'Negotiation Skills', 'Customer Handling', 'Dispatch Operations'],
    color: 'from-orange-500 to-orange-600',
  },
  {
    icon: TrendingUp,
    title: 'Freight Brokerage',
    duration: '20 Days',
    fee: '₹30,000',
    topics: ['Freight Market Basics', 'Shipper Acquisition', 'Carrier Sourcing', 'Rate Negotiation', 'Broker Operations', 'Freight Management'],
    color: 'from-navy-500 to-navy-700',
  },
  {
    icon: Calculator,
    title: 'Dispatch Accounting',
    duration: '20 Days',
    fee: '₹20,000',
    topics: ['Invoicing', 'Factoring', 'Driver Settlements', 'Expense Management', 'Financial Reporting'],
    color: 'from-emerald-500 to-emerald-700',
  },
  {
    icon: ShieldCheck,
    title: 'Driver/Truck Safety & Compliance',
    duration: '20 Days',
    fee: '₹25,000',
    topics: ['DOT Compliance', 'ELD Systems', 'Driver Safety', 'Log Book Management', 'Regulatory Requirements'],
    color: 'from-rose-500 to-rose-700',
  },
];

export const COMBO_PROGRAMS = [
  {
    icon: Zap,
    title: 'Truck Dispatching Professional Program',
    fee: '₹40,000',
    duration: '45 Days',
    includes: ['Complete Truck Dispatching', 'Advanced Dispatch Operations', 'Basics of Freight Brokerage', 'Basics of Dispatch Accounting', 'Basics of Safety & Compliance'],
    description: 'Best for beginners wanting complete dispatching knowledge.',
    badge: 'Popular',
    featured: false,
  },
  {
    icon: Zap,
    title: 'Advance Dispatching Master Program',
    fee: '₹60,000',
    duration: '60 Days',
    includes: ['Truck Dispatching', 'Freight Brokerage', 'Dispatch Accounting', 'Driver Safety & Compliance', 'Advanced Industry Training'],
    description: 'Most comprehensive program offered by IDT Campus.',
    badge: 'Most Comprehensive',
    featured: true,
  },
];

export const PLATFORMS = ['ITS Dispatch', 'Samsara', 'Avaal', 'Amazon Relay', 'Canadian Tire', 'Loadlink'];

export const WHY_CHOOSE = [
  { icon: 'Briefcase', title: '100% Practical Learning', desc: 'Hands-on training on real industry tools — no boring theory.' },
  { icon: 'Globe', title: 'Real-Time Industry Exposure', desc: 'Work with live dispatching scenarios and real freight data.' },
  { icon: 'Monitor', title: 'Live Software Training', desc: 'Learn on the same platforms used by top US & Canadian carriers.' },
  { icon: 'Users', title: 'Experienced Mentors', desc: 'Trainers with years of hands-on trucking industry experience.' },
  { icon: 'Target', title: 'Job-Oriented Curriculum', desc: 'Curriculum designed around what employers actually need.' },
  { icon: 'Compass', title: 'Career Guidance', desc: 'Personalized guidance to help you land the right logistics role.' },
  { icon: 'MessageSquare', title: 'Interview Preparation', desc: 'Mock interviews and resume prep to make you interview-ready.' },
  { icon: 'UserCheck', title: 'Small Batch Training', desc: 'Limited seats per batch ensure individual attention for every student.' },
  { icon: 'Clock', title: 'Flexible Learning Environment', desc: 'Schedule options that fit working professionals and students alike.' },
];

export const TESTIMONIALS = [
  {
    name: 'Harpreet Singh',
    course: 'Truck Dispatching Professional Program',
    rating: 5,
    review: 'IDT Campus completely transformed my career. The practical training on ITS Dispatch and Amazon Relay gave me the confidence to handle real loads from day one. Within a month of completing the course, I was hired as a dispatcher for a US carrier.',
  },
  {
    name: 'Simran Kaur',
    course: 'Advance Dispatching Master Program',
    rating: 5,
    review: 'The master program is incredibly comprehensive. From freight brokerage to accounting and compliance, I learned everything I needed. The mentors are always available to answer questions, and the small batch size meant I got personal attention.',
  },
  {
    name: 'Rohit Sharma',
    course: 'Freight Brokerage',
    rating: 5,
    review: 'I came in with zero logistics background and now I am confidently negotiating rates and sourcing carriers. The live software training on Samsara and Loadlink was a game-changer. Highly recommend IDT Campus to anyone serious about this industry.',
  },
  {
    name: 'Navdeep Brar',
    course: 'Dispatch Accounting',
    rating: 5,
    review: 'The accounting course covered invoicing, factoring, and driver settlements in a way that was easy to follow. The trainers explained everything with real-world examples. This course gave me the skills to manage back-office operations efficiently.',
  },
  {
    name: 'Gurleen Sandhu',
    course: 'Driver/Truck Safety & Compliance',
    rating: 5,
    review: 'Compliance training at IDT Campus is top-notch. Learning DOT regulations, ELD systems, and log book management prepared me for a compliance officer role. The practical scenarios made complex regulations easy to understand.',
  },
  {
    name: 'Arjun Mehta',
    course: 'Advance Dispatching Master Program',
    rating: 5,
    review: 'Best decision I ever made. The 60-day program covered every aspect of dispatching and logistics. The career guidance and interview prep sessions helped me crack my first job. IDT Campus truly cares about student success.',
  },
];

export const FAQS = [
  {
    q: 'Do I need prior experience?',
    a: 'No prior experience is required. Our courses are designed for beginners and cover everything from the basics to advanced operations. Our mentors guide you step by step through every concept.',
  },
  {
    q: 'Is training practical or theoretical?',
    a: 'Our training is 100% practical. You will work on real industry software and platforms, handle live dispatching scenarios, and gain hands-on experience that mirrors what you will do on the job.',
  },
  {
    q: 'Will I learn real software?',
    a: 'Yes. We train you on actual industry platforms including ITS Dispatch, Samsara, Avaal, Amazon Relay, Canadian Tire, and Loadlink — the same tools used by professionals in the US and Canadian trucking industries.',
  },
  {
    q: 'Are classes available offline?',
    a: 'Yes, all classes are conducted in-person at our campus in Jalandhar, Punjab. We believe in face-to-face practical training with direct mentor interaction for the best learning experience.',
  },
  {
    q: "Which countries' trucking systems are covered?",
    a: 'Our training primarily focuses on the US and Canadian trucking industries. You will learn the dispatching, compliance, and operational standards specific to these markets.',
  },
  {
    q: 'Do you provide career guidance?',
    a: 'Absolutely. We provide career guidance, interview preparation, resume building, and placement assistance to help you land the right logistics role after completing your course.',
  },
  {
    q: 'What is included in combo courses?',
    a: 'Combo programs bundle multiple individual courses at a reduced fee. The Professional Program includes complete dispatching plus basics of brokerage, accounting, and compliance. The Master Program covers all four courses in depth plus advanced industry training.',
  },
];

export const CONTACT = {
  name: 'IDT Campus',
  address: 'First Floor, Kaki Pind, Hoshiarpur Road, Rama Mandi, Jalandhar, Punjab – 144005',
  phone: '+91 7341151010',
  phoneRaw: '917341151010',
  email: 'dispatch@idtcampus.in',
  instagram: 'https://www.instagram.com/idtcampus',
  instagramHandle: '@idtcampus',
  website: 'idtcampus.in',
};
