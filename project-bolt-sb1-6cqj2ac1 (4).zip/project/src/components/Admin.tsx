import { useEffect, useState, type FormEvent } from 'react';
import { Clock3, LogIn, LogOut, RefreshCw, ShieldCheck, Users } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const STAFF_EMAIL = 'dispatch@idtcampus.in';
type SubmissionStatus = 'new' | 'contacted' | 'enrolled' | 'closed';

type Submission = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  course_interest: string | null;
  message: string;
  status: SubmissionStatus;
  submitted_at: string;
  updated_at: string;
};

const STATUS_OPTIONS: Array<{ value: SubmissionStatus; label: string }> = [
  { value: 'new', label: 'New' },
  { value: 'contacted', label: 'Contacted' },
  { value: 'enrolled', label: 'Enrolled' },
  { value: 'closed', label: 'Closed' },
];

const STATUS_STYLES: Record<SubmissionStatus, string> = {
  new: 'bg-orange-100 text-orange-700',
  contacted: 'bg-blue-100 text-blue-700',
  enrolled: 'bg-emerald-100 text-emerald-700',
  closed: 'bg-slate-100 text-slate-600',
};

function formatDate(value: string) {
  return new Intl.DateTimeFormat('en-IN', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(value));
}

export default function Admin() {
  const [sessionEmail, setSessionEmail] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [authForm, setAuthForm] = useState({ email: STAFF_EMAIL, password: '' });
  const [authError, setAuthError] = useState('');
  const [authMessage, setAuthMessage] = useState('');
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loadingSubmissions, setLoadingSubmissions] = useState(false);
  const [dashboardError, setDashboardError] = useState('');
  const [filter, setFilter] = useState<SubmissionStatus | 'all'>('all');

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      setSessionEmail(data.session?.user.email?.toLowerCase() ?? null);
      setAuthLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!mounted) return;
      setSessionEmail(nextSession?.user.email?.toLowerCase() ?? null);
      setAuthLoading(false);
    });

    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (sessionEmail === STAFF_EMAIL) {
      void loadSubmissions();
    } else {
      setSubmissions([]);
    }
  }, [sessionEmail]);

  async function loadSubmissions() {
    setLoadingSubmissions(true);
    setDashboardError('');

    const { data, error } = await supabase
      .from('contact_submissions')
      .select('id, name, email, phone, course_interest, message, status, submitted_at, updated_at')
      .order('submitted_at', { ascending: false });

    if (error) {
      console.error('Could not load staff submissions', error);
      setDashboardError('We could not load the student inquiries. Please try again.');
    } else {
      setSubmissions((data ?? []) as Submission[]);
    }

    setLoadingSubmissions(false);
  }

  async function handleAuthSubmit(event: FormEvent) {
    event.preventDefault();
    setAuthError('');
    setAuthMessage('');

    if (authForm.email.trim().toLowerCase() !== STAFF_EMAIL) {
      setAuthError(`Use the authorized staff email: ${STAFF_EMAIL}`);
      return;
    }

    const email = authForm.email.trim().toLowerCase();
    const result = authMode === 'login'
      ? await supabase.auth.signInWithPassword({ email, password: authForm.password })
      : await supabase.auth.signUp({ email, password: authForm.password });

    if (result.error) {
      console.error('Staff authentication failed', result.error);
      setAuthError(authMode === 'login' ? 'The email or password is not correct.' : 'This staff account could not be created. Please try signing in or contact support.');
      return;
    }

    if (authMode === 'signup') {
      setAuthMessage('Staff account created. You can now sign in.');
      setAuthMode('login');
      setAuthForm({ email: STAFF_EMAIL, password: '' });
    }
  }

  async function handleSignOut() {
    await supabase.auth.signOut();
    setSubmissions([]);
  }

  async function updateStatus(id: string, status: SubmissionStatus) {
    const { error } = await supabase
      .from('contact_submissions')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', id);

    if (error) {
      console.error('Could not update submission status', error);
      setDashboardError('We could not update that inquiry. Please try again.');
      return;
    }

    setSubmissions((current) => current.map((submission) => (
      submission.id === id ? { ...submission, status, updated_at: new Date().toISOString() } : submission
    )));
  }

  if (authLoading) {
    return <div className="flex min-h-screen items-center justify-center bg-navy-950 text-white">Loading staff area...</div>;
  }

  if (sessionEmail !== STAFF_EMAIL) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-navy-950 px-4 py-12">
        <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-2xl">
          <a href="/" className="text-sm font-bold text-orange-600">← Back to IDT Campus</a>
          <div className="mt-8 flex h-14 w-14 items-center justify-center rounded-2xl bg-navy-900 text-orange-500">
            <ShieldCheck className="h-7 w-7" />
          </div>
          <h1 className="mt-5 font-display text-2xl font-extrabold text-navy-900">Staff control area</h1>
          <p className="mt-2 text-sm leading-relaxed text-navy-600">Sign in to review and manage student inquiries securely.</p>

          <div className="mt-6 flex rounded-xl bg-navy-50 p-1">
            <button onClick={() => setAuthMode('login')} className={`flex-1 rounded-lg py-2.5 text-sm font-bold ${authMode === 'login' ? 'bg-white text-navy-900 shadow-sm' : 'text-navy-500'}`}>Sign in</button>
            <button onClick={() => setAuthMode('signup')} className={`flex-1 rounded-lg py-2.5 text-sm font-bold ${authMode === 'signup' ? 'bg-white text-navy-900 shadow-sm' : 'text-navy-500'}`}>Create staff account</button>
          </div>

          {authError && <div className="mt-5 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">{authError}</div>}
          {authMessage && <div className="mt-5 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-700">{authMessage}</div>}

          <form onSubmit={handleAuthSubmit} className="mt-6 space-y-4">
            <div>
              <label htmlFor="staff-email" className="block text-sm font-semibold text-navy-700">Staff email</label>
              <input id="staff-email" type="email" required value={authForm.email} onChange={(event) => setAuthForm({ ...authForm, email: event.target.value })} className="mt-2 w-full rounded-xl border border-navy-200 px-4 py-3 text-sm outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20" />
            </div>
            <div>
              <label htmlFor="staff-password" className="block text-sm font-semibold text-navy-700">Password</label>
              <input id="staff-password" type="password" required minLength={6} value={authForm.password} onChange={(event) => setAuthForm({ ...authForm, password: event.target.value })} className="mt-2 w-full rounded-xl border border-navy-200 px-4 py-3 text-sm outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20" />
            </div>
            <button type="submit" className="flex w-full items-center justify-center gap-2 rounded-xl bg-orange-500 py-3.5 text-sm font-bold text-white shadow-lg shadow-orange-500/25 hover:bg-orange-600">
              <LogIn className="h-4 w-4" />
              {authMode === 'login' ? 'Sign in to dashboard' : 'Create staff account'}
            </button>
          </form>
        </div>
      </main>
    );
  }

  const filteredSubmissions = filter === 'all' ? submissions : submissions.filter((submission) => submission.status === filter);
  const counts = submissions.reduce<Record<SubmissionStatus, number>>((result, submission) => {
    result[submission.status] += 1;
    return result;
  }, { new: 0, contacted: 0, enrolled: 0, closed: 0 });

  return (
    <main className="min-h-screen bg-navy-50/60">
      <header className="border-b border-white/10 bg-navy-950 text-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-5 sm:px-6 lg:px-8">
          <div>
            <a href="/" className="text-sm font-bold text-orange-400">IDT Campus</a>
            <h1 className="mt-1 font-display text-2xl font-extrabold">Student inquiries</h1>
          </div>
          <button onClick={handleSignOut} className="flex items-center gap-2 rounded-xl border border-white/20 px-4 py-2.5 text-sm font-bold hover:bg-white/10"><LogOut className="h-4 w-4" /> Sign out</button>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STATUS_OPTIONS.map((option) => (
            <button key={option.value} onClick={() => setFilter(option.value)} className={`rounded-2xl bg-white p-5 text-left shadow-sm ring-1 ring-navy-100 transition-all hover:-translate-y-1 ${filter === option.value ? 'ring-2 ring-orange-500' : ''}`}>
              <div className="flex items-center justify-between"><span className="text-sm font-semibold text-navy-500">{option.label}</span><span className={`rounded-full px-2 py-1 text-xs font-bold ${STATUS_STYLES[option.value]}`}>{counts[option.value]}</span></div>
              <div className="mt-3 font-display text-3xl font-extrabold text-navy-900">{counts[option.value]}</div>
            </button>
          ))}
        </div>

        <div className="mt-8 rounded-3xl bg-white p-5 shadow-xl ring-1 ring-navy-100 sm:p-7">
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
            <div><h2 className="font-display text-xl font-extrabold text-navy-900">All student inquiries</h2><p className="mt-1 text-sm text-navy-500">Review applications and update their progress.</p></div>
            <button onClick={() => void loadSubmissions()} className="flex items-center justify-center gap-2 rounded-xl border border-navy-200 px-4 py-2.5 text-sm font-bold text-navy-700 hover:border-orange-400 hover:text-orange-600"><RefreshCw className={`h-4 w-4 ${loadingSubmissions ? 'animate-spin' : ''}`} /> Refresh</button>
          </div>

          {dashboardError && <div className="mt-5 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">{dashboardError}</div>}

          {loadingSubmissions ? (
            <div className="flex items-center justify-center gap-2 py-16 text-sm text-navy-500"><RefreshCw className="h-5 w-5 animate-spin" /> Loading inquiries...</div>
          ) : filteredSubmissions.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center"><Users className="h-10 w-10 text-navy-300" /><p className="mt-4 font-bold text-navy-800">No inquiries in this view</p><p className="mt-1 text-sm text-navy-500">New website submissions will appear here.</p></div>
          ) : (
            <div className="mt-6 space-y-4">
              {filteredSubmissions.map((submission) => (
                <article key={submission.id} className="rounded-2xl border border-navy-100 p-5 transition-colors hover:border-orange-200">
                  <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-start">
                    <div className="min-w-0"><div className="flex flex-wrap items-center gap-3"><h3 className="font-display text-lg font-bold text-navy-900">{submission.name}</h3><span className={`rounded-full px-2.5 py-1 text-xs font-bold ${STATUS_STYLES[submission.status]}`}>{submission.status}</span></div><div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-navy-600"><a href={`mailto:${submission.email}`} className="hover:text-orange-600">{submission.email}</a>{submission.phone && <a href={`tel:${submission.phone}`} className="hover:text-orange-600">{submission.phone}</a>}</div></div>
                    <div className="flex items-center gap-2 text-xs text-navy-400"><Clock3 className="h-4 w-4" /> {formatDate(submission.submitted_at)}</div>
                  </div>
                  <div className="mt-4 grid gap-4 border-t border-navy-100 pt-4 md:grid-cols-[1fr_220px]"><div><p className="text-xs font-bold uppercase tracking-wide text-navy-400">Course interest</p><p className="mt-1 text-sm font-semibold text-navy-800">{submission.course_interest || 'Not specified'}</p><p className="mt-4 text-xs font-bold uppercase tracking-wide text-navy-400">Message</p><p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed text-navy-600">{submission.message}</p></div><div><label htmlFor={`status-${submission.id}`} className="text-xs font-bold uppercase tracking-wide text-navy-400">Update status</label><select id={`status-${submission.id}`} value={submission.status} onChange={(event) => void updateStatus(submission.id, event.target.value as SubmissionStatus)} className="mt-2 w-full rounded-xl border border-navy-200 bg-white px-3 py-2.5 text-sm font-semibold text-navy-800 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20">{STATUS_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></div></div>
                </article>
              ))}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
