import { MessageCircle } from 'lucide-react';
import { CONTACT } from '@/data';

export default function FloatingWhatsApp() {
  const text = encodeURIComponent("Hello IDT Campus, I'd like to know more about your training programs.");

  return (
    <a
      href={`https://wa.me/${CONTACT.phoneRaw}?text=${text}`}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-white shadow-2xl shadow-emerald-500/40 transition-all hover:bg-emerald-600 hover:scale-110 active:scale-95 animate-pulse-glow"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="h-7 w-7" />
    </a>
  );
}
