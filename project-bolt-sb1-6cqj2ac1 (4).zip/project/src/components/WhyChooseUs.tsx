import { Briefcase, Globe, Monitor, Users, Target, Compass, MessageSquare, UserCheck, Clock, Award } from 'lucide-react';
import { WHY_CHOOSE } from '@/data';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Briefcase, Globe, Monitor, Users, Target, Compass, MessageSquare, UserCheck, Clock,
};

export default function WhyChooseUs() {
  return (
    <section id="why-us" className="relative overflow-hidden bg-navy-50/30 py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="reveal inline-flex items-center gap-2 rounded-full bg-orange-100 px-4 py-2 text-sm font-semibold text-orange-600">
            <Award className="h-4 w-4" />
            Why Choose Us
          </div>
          <h2 className="reveal reveal-delay-1 mt-5 font-display text-3xl font-extrabold text-navy-900 sm:text-4xl">
            The IDT Campus Advantage
          </h2>
          <p className="reveal reveal-delay-2 mx-auto mt-4 max-w-2xl text-base text-navy-600">
            We go beyond traditional classroom teaching to give you the skills, confidence, and industry exposure needed to succeed in logistics.
          </p>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {WHY_CHOOSE.map((item, i) => {
            const Icon = iconMap[item.icon];
            return (
              <div
                key={item.title}
                className={`reveal reveal-delay-${(i % 3) + 1} card-lift group relative overflow-hidden rounded-2xl bg-white p-7 shadow-md ring-1 ring-navy-100`}
              >
                {/* Hover gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-navy-900 to-navy-800 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

                <div className="relative">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-orange-600 text-white shadow-lg transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3">
                    <Icon className="h-7 w-7" />
                  </div>

                  <h3 className="mt-5 font-display text-lg font-bold text-navy-900 transition-colors duration-300 group-hover:text-white">
                    {item.title}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-navy-600 transition-colors duration-300 group-hover:text-navy-200">
                    {item.desc}
                  </p>
                </div>

                {/* Number badge */}
                <div className="absolute top-6 right-6 font-display text-5xl font-extrabold text-navy-50 transition-colors duration-300 group-hover:text-white/10">
                  {String(i + 1).padStart(2, '0')}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}


