import { Phone, Mail, MapPin, Instagram, Globe, Truck, ArrowUp } from 'lucide-react';
import Logo from './Logo';
import { CONTACT } from '@/data';

const QUICK_LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'About Us', href: '#about' },
  { label: 'Courses', href: '#courses' },
  { label: 'Combo Programs', href: '#programs' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Contact', href: '#contact' },
];

const COURSE_LINKS = [
  { label: 'Truck Dispatching', href: '#courses' },
  { label: 'Freight Brokerage', href: '#courses' },
  { label: 'Dispatch Accounting', href: '#courses' },
  { label: 'Safety & Compliance', href: '#courses' },
  { label: 'Professional Program', href: '#programs' },
  { label: 'Master Program', href: '#programs' },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-navy-950 text-white">
      {/* Decorative top border */}
      <div className="h-1 bg-gradient-to-r from-orange-500 via-orange-400 to-orange-500" />

      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute -top-10 -right-10 h-64 w-64 rounded-full bg-orange-500 blur-3xl" />
        <div className="absolute bottom-0 -left-10 h-64 w-64 rounded-full bg-navy-400 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Main footer */}
        <div className="grid grid-cols-1 gap-10 py-14 md:grid-cols-2 lg:grid-cols-4">
          {/* About */}
          <div className="lg:col-span-1">
            <Logo light />
            <p className="mt-5 text-sm leading-relaxed text-navy-200">
              IDT Campus is a professional logistics training academy dedicated to providing practical and real-world training in Truck Dispatching and Logistics Operations for the US and Canadian trucking industries.
            </p>
            <div className="mt-5 flex gap-3">
              <a
                href={CONTACT.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/10 text-white transition-all hover:bg-orange-500 hover:scale-110"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href={`tel:${CONTACT.phoneRaw}`}
                className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/10 text-white transition-all hover:bg-orange-500 hover:scale-110"
                aria-label="Call"
              >
                <Phone className="h-5 w-5" />
              </a>
              <a
                href={`mailto:${CONTACT.email}`}
                className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/10 text-white transition-all hover:bg-orange-500 hover:scale-110"
                aria-label="Email"
              >
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-display text-base font-bold text-white">Quick Links</h3>
            <ul className="mt-5 space-y-3">
              {QUICK_LINKS.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="group flex items-center gap-2 text-sm text-navy-200 transition-colors hover:text-orange-400"
                  >
                    <Truck className="h-3.5 w-3.5 text-orange-500 transition-transform group-hover:translate-x-1" />
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Courses */}
          <div>
            <h3 className="font-display text-base font-bold text-white">Our Courses</h3>
            <ul className="mt-5 space-y-3">
              {COURSE_LINKS.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="group flex items-center gap-2 text-sm text-navy-200 transition-colors hover:text-orange-400"
                  >
                    <Truck className="h-3.5 w-3.5 text-orange-500 transition-transform group-hover:translate-x-1" />
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-display text-base font-bold text-white">Contact Info</h3>
            <ul className="mt-5 space-y-4">
              <li className="flex gap-3">
                <MapPin className="h-5 w-5 flex-shrink-0 text-orange-500" />
                <span className="text-sm leading-relaxed text-navy-200">{CONTACT.address}</span>
              </li>
              <li>
                <a href={`tel:${CONTACT.phoneRaw}`} className="flex gap-3 text-sm text-navy-200 transition-colors hover:text-orange-400">
                  <Phone className="h-5 w-5 flex-shrink-0 text-orange-500" />
                  {CONTACT.phone}
                </a>
              </li>
              <li>
                <a href={`mailto:${CONTACT.email}`} className="flex gap-3 text-sm text-navy-200 transition-colors hover:text-orange-400">
                  <Mail className="h-5 w-5 flex-shrink-0 text-orange-500" />
                  {CONTACT.email}
                </a>
              </li>
              <li className="flex gap-3">
                <Globe className="h-5 w-5 flex-shrink-0 text-orange-500" />
                <span className="text-sm text-navy-200">{CONTACT.website}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/10 py-6">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <div className="flex flex-wrap items-center justify-center gap-4 sm:justify-start">
              <p className="text-sm text-navy-300">© 2026 IDT Campus. All Rights Reserved.</p>
              <a href="/admin" className="text-xs font-semibold text-navy-400 transition-colors hover:text-orange-400">Staff login</a>
            </div>
            <a
              href="#home"
              className="flex items-center gap-2 rounded-lg bg-white/10 px-4 py-2 text-sm font-medium text-white transition-all hover:bg-orange-500"
            >
              Back to Top
              <ArrowUp className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
