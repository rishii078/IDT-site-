import { Monitor, CheckCircle2, ArrowRight } from 'lucide-react';
import { PLATFORMS } from '@/data';

export default function Platforms() {
  return (
    <section id="platforms" className="relative overflow-hidden bg-white py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Content */}
          <div>
            <div className="reveal inline-flex items-center gap-2 rounded-full bg-navy-100 px-4 py-2 text-sm font-semibold text-navy-700">
              <Monitor className="h-4 w-4" />
              Real-Time Practical Training
            </div>

            <h2 className="reveal reveal-delay-1 mt-5 font-display text-3xl font-extrabold leading-tight text-navy-900 sm:text-4xl">
              Train on <span className="text-orange-500">Real Industry Platforms</span>
            </h2>

            <p className="reveal reveal-delay-2 mt-6 text-base leading-relaxed text-navy-600">
              Students receive hands-on practical training on real logistics software and websites. We don't just teach theory — you'll work with the exact same platforms used by professionals in the US and Canadian trucking industries.
            </p>

            <div className="reveal reveal-delay-3 mt-8 grid gap-3 sm:grid-cols-2">
              {PLATFORMS.map((platform) => (
                <div
                  key={platform}
                  className="flex items-center gap-3 rounded-xl border border-navy-100 bg-navy-50/50 px-4 py-3 transition-all hover:border-orange-300 hover:bg-orange-50"
                >
                  <CheckCircle2 className="h-5 w-5 flex-shrink-0 text-orange-500" />
                  <span className="text-sm font-bold text-navy-900">{platform}</span>
                </div>
              ))}
            </div>

            <a
              href="#contact"
              className="reveal reveal-delay-4 mt-8 inline-flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition-all hover:bg-orange-600 active:scale-95"
            >
              Start Training Today
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>

          {/* Right: Platform showcase */}
          <div className="reveal reveal-delay-2 relative">
            <div className="absolute -inset-4 rounded-3xl bg-gradient-to-tr from-orange-500/10 to-navy-400/10 blur-2xl" />

            {/* Browser window mockup */}
            <div className="relative rounded-2xl border border-navy-200 bg-white shadow-2xl overflow-hidden">
              {/* Browser bar */}
              <div className="flex items-center gap-2 border-b border-navy-100 bg-navy-50 px-4 py-3">
                <div className="flex gap-1.5">
                  <div className="h-3 w-3 rounded-full bg-red-400" />
                  <div className="h-3 w-3 rounded-full bg-yellow-400" />
                  <div className="h-3 w-3 rounded-full bg-green-400" />
                </div>
                <div className="ml-3 flex-1 rounded-md bg-white px-3 py-1 text-xs text-navy-400">
                  its-dispatch.com — Live Training
                </div>
              </div>

              {/* Mock dashboard */}
              <div className="p-5 bg-navy-50/30">
                <div className="grid grid-cols-3 gap-3">
                  {PLATFORMS.map((p, i) => (
                    <div
                      key={p}
                      className="rounded-xl bg-white p-4 text-center shadow-sm ring-1 ring-navy-100 transition-all hover:ring-orange-300"
                      style={{ animationDelay: `${i * 0.1}s` }}
                    >
                      <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-navy-700 to-navy-900 text-xs font-extrabold text-white">
                        {p.split(' ').map(w => w[0]).join('').slice(0, 2)}
                      </div>
                      <div className="mt-2 text-xs font-bold text-navy-700">{p}</div>
                      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-navy-100">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-orange-500 to-orange-400"
                          style={{ width: `${65 + i * 5}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Mock load board */}
                <div className="mt-4 rounded-xl bg-white p-4 shadow-sm ring-1 ring-navy-100">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-navy-900">Live Load Board</span>
                    <span className="flex items-center gap-1.5 text-emerald-600">
                      <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                      Active
                    </span>
                  </div>
                  <div className="mt-3 space-y-2">
                    {[
                      { from: 'Chicago, IL', to: 'Dallas, TX', rate: '$2,400' },
                      { from: 'Toronto, ON', to: 'Montreal, QC', rate: '$1,800' },
                      { from: 'Atlanta, GA', to: 'Miami, FL', rate: '$1,950' },
                    ].map((load) => (
                      <div key={load.from} className="flex items-center justify-between rounded-lg bg-navy-50/50 px-3 py-2 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-navy-700">{load.from}</span>
                          <ArrowRight className="h-3 w-3 text-orange-500" />
                          <span className="font-semibold text-navy-700">{load.to}</span>
                        </div>
                        <span className="font-bold text-orange-600">{load.rate}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
