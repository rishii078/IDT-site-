import { useState, type FormEvent } from 'react';
import { Phone, Mail, MapPin, Instagram, Send, MessageCircle, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { CONTACT, COURSES, COMBO_PROGRAMS } from '@/data';
import { supabase } from '@/lib/supabase';

const COURSE_OPTIONS = [
  ...COURSES.map((c) => c.title),
  ...COMBO_PROGRAMS.map((p) => p.title),
];

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', course_interest: '', message: '' });
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setStatus('loading');

    try {
      const { error } = await supabase.from('contact_submissions').insert({
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        course_interest: form.course_interest || null,
        message: form.message,
      });

      if (error) throw error;

      setStatus('success');
      setForm({ name: '', email: '', phone: '', course_interest: '', message: '' });

      setTimeout(() => setStatus('idle'), 5000);
    } catch {
      setStatus('error');
      setTimeout(() => setStatus('idle'), 5000);
    }
  };

  const whatsappText = encodeURIComponent("Hello IDT Campus, I'd like to know more about your training programs.");

  return (
    <section id="contact" className="relative overflow-hidden bg-white py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="reveal inline-flex items-center gap-2 rounded-full bg-orange-100 px-4 py-2 text-sm font-semibold text-orange-600">
            <MessageCircle className="h-4 w-4" />
            Contact Us
          </div>
          <h2 className="reveal reveal-delay-1 mt-5 font-display text-3xl font-extrabold text-navy-900 sm:text-4xl">
            Get in Touch
          </h2>
          <p className="reveal reveal-delay-2 mx-auto mt-4 max-w-2xl text-base text-navy-600">
            Ready to start your logistics career? Reach out to us and take the first step toward becoming a professional truck dispatcher.
          </p>
        </div>

        <div className="mt-14 grid gap-8 lg:grid-cols-2">
          {/* Left: Contact info + map */}
          <div className="reveal space-y-6">
            {/* Contact info card */}
            <div className="rounded-3xl bg-navy-900 p-8 text-white shadow-xl">
              <h3 className="font-display text-xl font-bold">IDT Campus</h3>
              <p className="mt-1 text-sm text-navy-200">Logistics Training Academy</p>

              <div className="mt-6 space-y-5">
                <div className="flex gap-4">
                  <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl bg-orange-500/20 text-orange-400">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wide text-navy-300">Address</div>
                    <p className="mt-1 text-sm leading-relaxed text-white">{CONTACT.address}</p>
                  </div>
                </div>

                <a href={`tel:${CONTACT.phoneRaw}`} className="flex gap-4 transition-opacity hover:opacity-80">
                  <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl bg-orange-500/20 text-orange-400">
                    <Phone className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wide text-navy-300">Phone</div>
                    <p className="mt-1 text-sm font-bold text-white">{CONTACT.phone}</p>
                  </div>
                </a>

                <a href={`mailto:${CONTACT.email}`} className="flex gap-4 transition-opacity hover:opacity-80">
                  <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl bg-orange-500/20 text-orange-400">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wide text-navy-300">Email</div>
                    <p className="mt-1 text-sm font-bold text-white">{CONTACT.email}</p>
                  </div>
                </a>

                <a href={CONTACT.instagram} target="_blank" rel="noopener noreferrer" className="flex gap-4 transition-opacity hover:opacity-80">
                  <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl bg-orange-500/20 text-orange-400">
                    <Instagram className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wide text-navy-300">Instagram</div>
                    <p className="mt-1 text-sm font-bold text-white">{CONTACT.instagramHandle}</p>
                  </div>
                </a>
              </div>

              {/* Quick action buttons */}
              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href={`tel:${CONTACT.phoneRaw}`}
                  className="flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition-all hover:bg-orange-600 active:scale-95"
                >
                  <Phone className="h-4 w-4" />
                  Call Now
                </a>
                <a
                  href={`https://wa.me/${CONTACT.phoneRaw}?text=${whatsappText}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 rounded-xl bg-emerald-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-500/30 transition-all hover:bg-emerald-600 active:scale-95"
                >
                  <MessageCircle className="h-4 w-4" />
                  WhatsApp
                </a>
              </div>
            </div>

            {/* Google Map */}
            <div className="overflow-hidden rounded-3xl shadow-xl ring-1 ring-navy-100">
              <iframe
                title="IDT Campus Location"
                src="https://www.google.com/maps?q=First+Floor,+Kaki+Pind,+Hoshiarpur+Road,+Rama+Mandi,+Jalandhar,+Punjab+144005&output=embed"
                width="100%"
                height="300"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>

          {/* Right: Contact form */}
          <div className="reveal reveal-delay-1">
            <div className="rounded-3xl border border-navy-100 bg-white p-8 shadow-xl">
              <h3 className="font-display text-xl font-bold text-navy-900">Send Us a Message</h3>
              <p className="mt-2 text-sm text-navy-500">Fill out the form below and we'll get back to you within 24 hours.</p>

              {status === 'success' && (
                <div className="mt-6 flex items-center gap-3 rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-4">
                  <CheckCircle2 className="h-6 w-6 flex-shrink-0 text-emerald-600" />
                  <div>
                    <p className="font-bold text-sm text-emerald-800">Message sent successfully!</p>
                    <p className="text-xs text-emerald-600">We'll get back to you soon.</p>
                  </div>
                </div>
              )}

              {status === 'error' && (
                <div className="mt-6 flex items-center gap-3 rounded-xl bg-red-50 border border-red-200 px-4 py-4">
                  <AlertCircle className="h-6 w-6 flex-shrink-0 text-red-600" />
                  <div>
                    <p className="font-bold text-sm text-red-800">Something went wrong.</p>
                    <p className="text-xs text-red-600">Please try again or call us directly.</p>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="mt-6 space-y-5">
                <div className="grid gap-5 sm:grid-cols-2">
                  <div>
                    <label htmlFor="name" className="block text-sm font-semibold text-navy-700">Full Name *</label>
                    <input
                      id="name"
                      name="name"
                      type="string"
                      required
                      value={form.name}
                      onChange={handleChange}
                      className="mt-2 w-full rounded-xl border border-navy-200 px-4 py-3 text-sm text-navy-900 outline-none transition-all focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20"
                      placeholder="Name"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-semibold text-navy-700">Email *</label>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={form.email}
                      onChange={handleChange}
                      className="mt-2 w-full rounded-xl border border-navy-200 px-4 py-3 text-sm text-navy-900 outline-none transition-all focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20"
                      placeholder="john@example.com"
                    />
                  </div>
                </div>

                <div className="grid gap-5 sm:grid-cols-2">
                  <div>
                    <label htmlFor="phone" className="block text-sm font-semibold text-navy-700">Phone</label>
                    <input
                      id="phone"
                      name="phone"
                      
                      type="numeric"
                        
                      value={form.phone}
                      onChange={handleChange}
                      className="mt-2 w-full rounded-xl border border-navy-200 px-4 py-3 text-sm text-navy-900 outline-none transition-all focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20"
                      placeholder="Enter Your Mobile Number"
                     maxlength={10}
                      patteren="[0-9]{10}"
                      inputMode="numeric"
                      required
                      
                    />
                  </div>
                  <div>
                    <label htmlFor="course_interest" className="block text-sm font-semibold text-navy-700">Course Interest</label>
                    <select
                      id="course_interest"
                      name="course_interest"
                      value={form.course_interest}
                      onChange={handleChange}
                      className="mt-2 w-full rounded-xl border border-navy-200 px-4 py-3 text-sm text-navy-900 outline-none transition-all focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 bg-white"
                    >
                      <option value="">Select a course</option>
                      {COURSE_OPTIONS.map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-navy-700">Message *</label>
                  <textarea
                    id="message"
                    name="message"
                    required
                    rows={5}
                    value={form.message}
                    onChange={handleChange}
                    className="mt-2 w-full rounded-xl border border-navy-200 px-4 py-3 text-sm text-navy-900 outline-none transition-all focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 resize-none"
                    placeholder="Tell us about your goals and questions..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={status === 'loading'}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-orange-500 py-3.5 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition-all hover:bg-orange-600 active:scale-95 disabled:opacity-60 disabled:active:scale-100"
                >
                  {status === 'loading' ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      Send Message
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
