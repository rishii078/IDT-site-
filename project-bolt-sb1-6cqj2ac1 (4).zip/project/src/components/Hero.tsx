import { ArrowRight, Phone, CheckCircle2, Truck, Users, Monitor, Briefcase, MapPin } from 'lucide-react';
import { HERO_MEDIA } from '@/data/media';

const HIGHLIGHTS = [
  { icon: Monitor, text: 'Real-Time Practical Training' },
  { icon: Users, text: 'Industry Expert Guidance' },
  { icon: Truck, text: 'Live Dispatching Scenarios' },
  { icon: Briefcase, text: 'Placement Assistance' },
  { icon: CheckCircle2, text: 'Small Batch Sizes' },
];

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen overflow-hidden bg-navy-900">
      {/* Full-screen company logo background */}
      <div className="absolute inset-0 bg-navy-900">
        <img
          src={HERO_MEDIA.backgroundImage}
          alt=""
          aria-hidden="true"
          className="h-full w-full object-cover object-center mix-blend-multiply opacity-95"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-navy-950/90 via-navy-900/75 to-navy-900/55" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/95 via-transparent to-navy-950/40" />
      </div>

      {/* Decorative glows */}
      <div className="absolute -top-20 right-0 h-96 w-96 rounded-full bg-orange-500/10 blur-3xl" />
      <div className="absolute bottom-0 left-0 h-96 w-96 rounded-full bg-navy-400/10 blur-3xl" />

      {/* Content */}
      <div className="relative mx-auto flex min-h-screen max-w-7xl flex-col justify-center px-4 pt-24 pb-16 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Text content */}
          <div className="text-white">
            <div className="animate-fade-in-up inline-flex items-center gap-2 rounded-full border border-orange-500/30 bg-orange-500/10 px-4 py-2 text-sm font-medium text-orange-400 backdrop-blur-sm">
              <MapPin className="h-4 w-4" />
              Jalandhar, Punjab — India
            </div>

            <h1 className="animate-fade-in-up mt-6 font-display text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl lg:text-6xl" style={{ animationDelay: '0.1s', opacity: 0 }}>
              Become a <span className="gradient-text">Professional Truck Dispatcher</span> & Logistics Expert
            </h1>

            <p className="animate-fade-in-up mt-6 max-w-xl text-lg leading-relaxed text-navy-100" style={{ animationDelay: '0.2s', opacity: 0 }}>
              Get Real-Time Practical Training on Industry Platforms and Build a Successful Career in Truck Dispatching, Freight Brokerage, Accounting, and Compliance.
            </p>

            <div className="animate-fade-in-up mt-8 flex flex-wrap gap-4" style={{ animationDelay: '0.3s', opacity: 0 }}>
              <a
                href="#contact"
                className="group flex items-center gap-2 rounded-xl bg-orange-500 px-7 py-3.5 text-base font-bold text-white shadow-xl shadow-orange-500/30 transition-all hover:bg-orange-600 hover:shadow-2xl hover:shadow-orange-500/40 active:scale-95"
              >
                Enroll Now
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
              </a>
              <a
                href="#contact"
                className="flex items-center gap-2 rounded-xl border-2 border-white/30 bg-white/5 px-7 py-3.5 text-base font-bold text-white backdrop-blur-sm transition-all hover:border-white/50 hover:bg-white/10"
              >
                <Phone className="h-5 w-5" />
                Contact Us
              </a>
            </div>

            {/* Highlights */}
            <div className="animate-fade-in-up mt-10 grid grid-cols-1 gap-3 sm:grid-cols-2" style={{ animationDelay: '0.4s', opacity: 0 }}>
              {HIGHLIGHTS.map((hl) => (
                <div
                  key={hl.text}
                  className="flex items-center gap-2.5 text-sm font-medium text-navy-100"
                >
                  <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-orange-500/20 text-orange-400">
                    <hl.icon className="h-4 w-4" />
                  </div>
                  {hl.text}
                </div>
              ))}
            </div>
          </div>

          {/* Right: Visual card */}
          <div className="hidden lg:block animate-scale-in" style={{ animationDelay: '0.3s', opacity: 0 }}>
            <div className="relative">
              <div className="absolute -inset-4 rounded-3xl bg-gradient-to-tr from-orange-500/20 to-navy-400/20 blur-2xl" />
              <div className="relative rounded-3xl border border-white/10 bg-white/5 p-8 backdrop-blur-md">
                <div className="flex items-center justify-center rounded-2xl bg-white/95 p-6 h-72">
                  <img
                    src={HERO_MEDIA.cardLogo}
                    alt="IDT Campus Institute of Dispatch logo"
                    className="h-full w-full object-contain"
                    loading="eager"
                  />
                </div>
                <div className="mt-6 grid grid-cols-3 gap-4">
                  {[
                    { num: '6', label: 'Specialized Courses' },
                    { num: '6', label: 'Industry Platforms' },
                    { num: '100%', label: 'Practical Training' },
                  ].map((stat) => (
                    <div key={stat.label} className="text-center rounded-xl bg-white/5 py-4">
                      <div className="font-display text-2xl font-extrabold text-orange-500">{stat.num}</div>
                      <div className="mt-1 text-xs text-navy-200">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Wave divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 100" fill="none" className="w-full" preserveAspectRatio="none">
          <path d="M0 100V40C240 80 480 80 720 60C960 40 1200 20 1440 40V100H0Z" fill="white" />
        </svg>
      </div>
    </section>
  );
}
