import { useState, useEffect, useCallback } from 'react';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';
import { TESTIMONIALS } from '@/data';

export default function Testimonials() {
  const [current, setCurrent] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const next = useCallback(() => setCurrent((c) => (c + 1) % TESTIMONIALS.length), []);
  const prev = useCallback(() => setCurrent((c) => (c - 1 + TESTIMONIALS.length) % TESTIMONIALS.length), []);

  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(next, 6000);
    return () => clearInterval(interval);
  }, [isPaused, next]);

  return (
    <section className="relative overflow-hidden bg-navy-900 py-24">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 h-72 w-72 rounded-full bg-orange-500 blur-3xl" />
        <div className="absolute bottom-10 right-10 h-72 w-72 rounded-full bg-navy-400 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="reveal inline-flex items-center gap-2 rounded-full bg-orange-500/20 px-4 py-2 text-sm font-semibold text-orange-400">
            <Star className="h-4 w-4" />
            Student Success Stories
          </div>
          <h2 className="reveal reveal-delay-1 mt-5 font-display text-3xl font-extrabold text-white sm:text-4xl">
            What Our Students Say
          </h2>
          <p className="reveal reveal-delay-2 mx-auto mt-4 max-w-2xl text-base text-navy-200">
            Real reviews from real students who transformed their careers with IDT Campus.
          </p>
        </div>

        <div
          className="reveal reveal-delay-3 relative mx-auto mt-14 max-w-4xl"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          {/* Quote icon */}
          <div className="absolute -top-6 -left-2 flex h-16 w-16 items-center justify-center rounded-2xl bg-orange-500 shadow-xl">
            <Quote className="h-8 w-8 text-white" />
          </div>

          {/* Carousel */}
          <div className="overflow-hidden rounded-3xl bg-white/5 border border-white/10 backdrop-blur-md">
            <div
              className="flex transition-transform duration-700 ease-out"
              style={{ transform: `translateX(-${current * 100}%)` }}
            >
              {TESTIMONIALS.map((t) => (
                <div key={t.name} className="w-full flex-shrink-0 p-8 sm:p-12">
                  <div className="flex gap-1">
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-orange-500 text-orange-500" />
                    ))}
                  </div>
                  <p className="mt-6 text-lg leading-relaxed text-white sm:text-xl">
                    "{t.review}"
                  </p>
                  <div className="mt-8 flex items-center gap-4">
                    <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-orange-500 to-orange-600 font-display text-lg font-extrabold text-white">
                      {t.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <div className="font-display text-lg font-bold text-white">{t.name}</div>
                      <div className="text-sm text-orange-400">{t.course}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Controls */}
          <div className="mt-8 flex items-center justify-center gap-4">
            <button
              onClick={prev}
              className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-white/20 text-white transition-all hover:border-orange-500 hover:bg-orange-500"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>

            {/* Dots */}
            <div className="flex gap-2">
              {TESTIMONIALS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrent(i)}
                  className={`h-2.5 rounded-full transition-all ${
                    current === i ? 'w-8 bg-orange-500' : 'w-2.5 bg-white/30 hover:bg-white/50'
                  }`}
                  aria-label={`Go to testimonial ${i + 1}`}
                />
              ))}
            </div>

            <button
              onClick={next}
              className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-white/20 text-white transition-all hover:border-orange-500 hover:bg-orange-500"
              aria-label="Next testimonial"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
