import { useCallback, useEffect, useMemo, useState } from 'react';
import { Camera, ArrowRight, X, ChevronLeft, ChevronRight, Maximize2 } from 'lucide-react';
import { GALLERY_IMAGES, GALLERY_CATEGORIES, type GalleryCategory, type GalleryImage } from '@/data/media';

type FilterValue = 'All' | GalleryCategory;

export default function Gallery() {
  const [filter, setFilter] = useState<FilterValue>('All');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const filteredImages = useMemo(() => {
    if (filter === 'All') return GALLERY_IMAGES;
    return GALLERY_IMAGES.filter((img) => img.category === filter);
  }, [filter]);

  const closeLightbox = useCallback(() => setLightboxIndex(null), []);

  const nextImage = useCallback(() => {
    setLightboxIndex((prev) => {
      if (prev === null) return prev;
      return (prev + 1) % filteredImages.length;
    });
  }, [filteredImages.length]);

  const prevImage = useCallback(() => {
    setLightboxIndex((prev) => {
      if (prev === null) return prev;
      return (prev - 1 + filteredImages.length) % filteredImages.length;
    });
  }, [filteredImages.length]);

  useEffect(() => {
    if (lightboxIndex === null) return;

    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight') nextImage();
      if (e.key === 'ArrowLeft') prevImage();
    };

    window.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [lightboxIndex, closeLightbox, nextImage, prevImage]);

  const openLightbox = (index: number) => setLightboxIndex(index);

  const filterOptions: FilterValue[] = ['All', ...GALLERY_CATEGORIES];

  return (
    <section id="gallery" className="relative overflow-hidden bg-white py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center">
          <div className="reveal inline-flex items-center gap-2 rounded-full bg-navy-100 px-4 py-2 text-sm font-semibold text-navy-700">
            <Camera className="h-4 w-4" />
            Gallery
          </div>
          <h2 className="reveal reveal-delay-1 mt-5 font-display text-3xl font-extrabold text-navy-900 sm:text-4xl">
            Life at IDT Campus
          </h2>
          <p className="reveal reveal-delay-2 mx-auto mt-4 max-w-2xl text-base text-navy-600">
            A glimpse into our classroom training, live dispatching sessions, practical demonstrations, and student activities. Real campus photos will be added soon.
          </p>
        </div>

        {/* Category filters */}
        <div className="reveal reveal-delay-2 mt-10 flex flex-wrap items-center justify-center gap-2">
          {filterOptions.map((option) => (
            <button
              key={option}
              onClick={() => setFilter(option)}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition-all ${
                filter === option
                  ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/25'
                  : 'bg-navy-50 text-navy-600 hover:bg-navy-100'
              }`}
            >
              {option}
            </button>
          ))}
        </div>

        {/* Gallery grid — responsive: 1 col mobile, 2 col tablet, 3 col desktop */}
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredImages.map((item, i) => (
            <GalleryCard
              key={item.id}
              item={item}
              onClick={() => openLightbox(i)}
              index={i}
              isFirstInAll={filter === 'All' && i === 0}
            />
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightboxIndex !== null && filteredImages[lightboxIndex] && (
        <Lightbox
          image={filteredImages[lightboxIndex]}
          onClose={closeLightbox}
          onNext={nextImage}
          onPrev={prevImage}
          currentIndex={lightboxIndex + 1}
          totalCount={filteredImages.length}
        />
      )}
    </section>
  );
}

function GalleryCard({
  item,
  onClick,
  isFirstInAll,
}: {
  item: GalleryImage;
  onClick: () => void;
  index: number;
  isFirstInAll: boolean;
}) {
  const aspectClass =
    item.aspect === 'tall' ? 'aspect-[3/4]' :
    item.aspect === 'square' ? 'aspect-square' :
    'aspect-video';

  return (
    <button
      onClick={onClick}
      className={`group relative overflow-hidden rounded-2xl shadow-lg ring-1 ring-navy-100 transition-all duration-300 hover:shadow-2xl ${
        isFirstInAll ? 'lg:col-span-2' : ''
      }`}
    >
      {/* Image — same aspect ratio that the final design will use */}
      <div className={`${aspectClass} w-full overflow-hidden bg-navy-100`}>
        <img
          src={item.image}
          alt={item.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
      </div>

      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/20 to-transparent opacity-70 transition-opacity duration-300 group-hover:opacity-90" />

      {/* Expand icon */}
      <div className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-lg bg-white/20 text-white opacity-0 backdrop-blur-sm transition-all duration-300 group-hover:opacity-100">
        <Maximize2 className="h-4 w-4" />
      </div>

      {/* Category badge */}
      <div className="absolute left-3 top-3 rounded-full bg-orange-500/90 px-3 py-1 text-xs font-bold text-white opacity-0 backdrop-blur-sm transition-all duration-300 group-hover:opacity-100">
        {item.category}
      </div>

      {/* Label */}
      <div className="absolute bottom-0 left-0 right-0 p-5">
        <div className="flex items-center justify-between">
          <h3 className="font-display text-lg font-bold text-white">{item.title}</h3>
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-orange-500/80 text-white opacity-0 transition-all duration-300 group-hover:opacity-100">
            <ArrowRight className="h-4 w-4" />
          </div>
        </div>
        <div className="mt-2 h-0.5 w-0 bg-orange-500 transition-all duration-500 group-hover:w-16" />
      </div>
    </button>
  );
}

function Lightbox({
  image,
  onClose,
  onNext,
  onPrev,
  currentIndex,
  totalCount,
}: {
  image: GalleryImage;
  onClose: () => void;
  onNext: () => void;
  onPrev: () => void;
  currentIndex: number;
  totalCount: number;
}) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-navy-950/95 backdrop-blur-sm">
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute right-4 top-4 z-10 flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white transition-all hover:bg-white/20 active:scale-95"
        aria-label="Close"
      >
        <X className="h-6 w-6" />
      </button>

      {/* Prev button */}
      <button
        onClick={onPrev}
        className="absolute left-3 top-1/2 z-10 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white transition-all hover:bg-white/20 active:scale-90 sm:left-6"
        aria-label="Previous image"
      >
        <ChevronLeft className="h-7 w-7" />
      </button>

      {/* Image container */}
      <div className="relative mx-auto max-h-[85vh] max-w-5xl px-16 sm:px-20">
        <img
          src={image.image}
          alt={image.title}
          className="mx-auto max-h-[85vh] w-auto rounded-2xl object-contain shadow-2xl"
        />

        {/* Caption */}
        <div className="mt-4 text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-orange-500/20 px-3 py-1 text-xs font-bold text-orange-400">
            {image.category}
          </div>
          <h3 className="mt-2 font-display text-xl font-bold text-white">{image.title}</h3>
          <p className="mt-1 text-sm text-navy-300">{currentIndex} / {totalCount}</p>
        </div>
      </div>

      {/* Next button */}
      <button
        onClick={onNext}
        className="absolute right-3 top-1/2 z-10 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white transition-all hover:bg-white/20 active:scale-90 sm:right-6"
        aria-label="Next image"
      >
        <ChevronRight className="h-7 w-7" />
      </button>

      {/* Click backdrop to close */}
      <div className="absolute inset-0 -z-0" onClick={onClose} />
    </div>
  );
}
