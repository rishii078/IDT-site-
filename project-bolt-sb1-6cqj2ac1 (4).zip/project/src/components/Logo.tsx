import { Truck } from 'lucide-react';

export default function Logo({ className = '', showText = true, light = false }: { className?: string; showText?: boolean; light?: boolean }) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <div className="relative flex-shrink-0">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-navy-900 ring-2 ring-orange-500/30">
          <Truck className="h-6 w-6 text-orange-500" strokeWidth={2.2} />
        </div>
        <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-orange-500 ring-2 ring-white" />
      </div>
      {showText && (
        <div className="flex flex-col leading-none">
          <span className={`font-display text-xl font-extrabold tracking-tight ${light ? 'text-white' : 'text-navy-900'}`}>
            IDT<span className="text-orange-500">Campus</span>
          </span>
          <span className={`text-[10px] font-medium tracking-wide ${light ? 'text-navy-200' : 'text-navy-500'}`}>
            Logistics Training Academy
          </span>
        </div>
      )}
    </div>
  );
}
