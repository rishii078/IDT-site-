import { useEffect, useState } from 'react';
import { Menu, X, Phone } from 'lucide-react';
import Logo from './Logo';
import { CONTACT } from '@/data';

const NAV_LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Courses', href: '#courses' },
  { label: 'Programs', href: '#programs' },
  { label: 'Platforms', href: '#platforms' },
  { label: 'Why Us', href: '#why-us' },
  { label: 'Videos', href: '#promo-videos' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Contact', href: '#contact' },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-white/95 backdrop-blur-md shadow-lg shadow-navy-900/5'
            : 'bg-transparent'
        }`}
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-18 items-center justify-between py-3">
            <a href="#home" aria-label="IDT Campus home">
              <Logo light={!scrolled} />
            </a>

            <nav className="hidden lg:flex items-center gap-1">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className={`rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                    scrolled
                      ? 'text-navy-700 hover:bg-navy-50 hover:text-navy-900'
                      : 'text-white/90 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {link.label}
                </a>
              ))}
            </nav>

            <div className="hidden lg:flex items-center gap-3">
              <a
                href={`tel:${CONTACT.phoneRaw}`}
                className={`flex items-center gap-2 text-sm font-semibold transition-colors ${
                  scrolled ? 'text-navy-700 hover:text-orange-500' : 'text-white/90 hover:text-orange-400'
                }`}
              >
                <Phone className="h-4 w-4" />
                {CONTACT.phone}
              </a>
              <a
                href="#contact"
                className="rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition-all hover:bg-orange-600 hover:shadow-xl hover:shadow-orange-500/40 active:scale-95"
              >
                Enroll Now
              </a>
            </div>

            <button
              onClick={() => setMobileOpen(true)}
              className={`lg:hidden p-2 rounded-lg transition-colors ${
                scrolled ? 'text-navy-900 hover:bg-navy-50' : 'text-white hover:bg-white/10'
              }`}
              aria-label="Open menu"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <div
        className={`fixed inset-0 z-[60] lg:hidden transition-opacity duration-300 ${
          mobileOpen ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
      >
        <div className="absolute inset-0 bg-navy-950/60 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
        <div
          className={`absolute right-0 top-0 h-full w-80 max-w-[85vw] bg-white shadow-2xl transition-transform duration-300 ${
            mobileOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div className="flex items-center justify-between border-b border-navy-100 px-5 py-4">
            <Logo />
            <button
              onClick={() => setMobileOpen(false)}
              className="p-2 rounded-lg text-navy-700 hover:bg-navy-50"
              aria-label="Close menu"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          <nav className="flex flex-col gap-1 px-4 py-4">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="rounded-lg px-4 py-3 text-sm font-medium text-navy-700 hover:bg-navy-50 hover:text-orange-500 transition-colors"
              >
                {link.label}
              </a>
            ))}
            <div className="mt-4 flex flex-col gap-3 px-1">
              <a
                href={`tel:${CONTACT.phoneRaw}`}
                className="flex items-center justify-center gap-2 rounded-xl border-2 border-navy-200 px-5 py-3 text-sm font-bold text-navy-900 transition-colors hover:border-navy-300"
              >
                <Phone className="h-4 w-4" />
                {CONTACT.phone}
              </a>
              <a
                href="#contact"
                onClick={() => setMobileOpen(false)}
                className="rounded-xl bg-orange-500 px-5 py-3 text-center text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition-all hover:bg-orange-600"
              >
                Enroll Now
              </a>
            </div>
          </nav>
        </div>
      </div>
    </>
  );
}
