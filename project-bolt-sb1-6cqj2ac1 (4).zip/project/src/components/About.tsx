import { Target, Eye, Award, Briefcase, Globe, Users, Monitor, TrendingUp, MessageSquare } from 'lucide-react';

const KEY_FEATURES = [
  { icon: 'Briefcase', title: 'Practical Training', desc: 'Hands-on learning on real platforms' },
  { icon: 'Globe', title: 'Live Industry Exposure', desc: 'Real-world dispatching scenarios' },
  { icon: 'Users', title: 'Experienced Trainers', desc: 'Industry veterans as mentors' },
  { icon: 'Monitor', title: 'Real Websites Training', desc: 'Train on actual logistics software' },
  { icon: 'TrendingUp', title: 'Career-Oriented Programs', desc: 'Designed for job readiness' },
  { icon: 'MessageSquare', title: 'Interview Preparation', desc: 'Mock interviews & resume prep' },
] as const;

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Briefcase, Globe, Users, Monitor, TrendingUp, MessageSquare,
};

export default function About() {
  return (
    <section id="about" className="relative overflow-hidden bg-white py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Image collage */}
          <div className="reveal relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <img
                  src="https://images.pexels.com/photos/1797428/pexels-photo-1797428.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Logistics warehouse operations"
                  className="rounded-2xl object-cover w-full h-48 shadow-lg"
                  loading="lazy"
                />
                <img
                  src="https://images.pexels.com/photos/4484073/pexels-photo-4484073.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Training session in progress"
                  className="rounded-2xl object-cover w-full h-64 shadow-lg"
                  loading="lazy"
                />
              </div>
              <div className="space-y-4 pt-8">
                <img
                  src="https://images.pexels.com/photos/35602229/pexels-photo-35602229.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Cargo truck on highway at sunset"
                  className="rounded-2xl object-cover w-full h-64 shadow-lg"
                  loading="lazy"
                />
                <img
                  src="https://images.pexels.com/photos/31112251/pexels-photo-31112251.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Organized inventory management"
                  className="rounded-2xl object-cover w-full h-48 shadow-lg"
                  loading="lazy"
                />
              </div>
            </div>

            {/* Floating badge */}
            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 rounded-2xl bg-navy-900 px-6 py-4 shadow-2xl">
              <div className="flex items-center gap-3">
                <Award className="h-8 w-8 text-orange-500" />
                <div>
                  <div className="font-display text-2xl font-extrabold text-white">500+</div>
                  <div className="text-xs text-navy-200">Professionals Trained</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Text content */}
          <div>
            <div className="reveal inline-flex items-center gap-2 rounded-full bg-orange-50 px-4 py-2 text-sm font-semibold text-orange-600">
              <Target className="h-4 w-4" />
              About IDT Campus
            </div>

            <h2 className="reveal reveal-delay-1 mt-5 font-display text-3xl font-extrabold leading-tight text-navy-900 sm:text-4xl">
              Building Skilled Logistics Professionals for the <span className="text-orange-500">US & Canadian Trucking Industries</span>
            </h2>

            <p className="reveal reveal-delay-2 mt-6 text-base leading-relaxed text-navy-600">
              IDT Campus is a professional logistics training academy dedicated to providing practical and real-world training in Truck Dispatching and Logistics Operations.
            </p>
            <p className="reveal reveal-delay-2 mt-4 text-base leading-relaxed text-navy-600">
              We focus on hands-on learning using actual industry software and platforms so students gain confidence and job-ready skills. Our mission is to create skilled logistics professionals capable of working in the US and Canadian trucking industries.
            </p>

            {/* Mission & Vision cards */}
            <div className="reveal reveal-delay-3 mt-8 grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl border border-navy-100 bg-navy-50/50 p-5">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-navy-900 text-orange-500">
                  <Target className="h-5 w-5" />
                </div>
                <h3 className="mt-3 font-display text-lg font-bold text-navy-900">Our Mission</h3>
                <p className="mt-2 text-sm leading-relaxed text-navy-600">
                  Create skilled logistics professionals ready for the global trucking industry through practical, hands-on training.
                </p>
              </div>
              <div className="rounded-2xl border border-navy-100 bg-navy-50/50 p-5">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-navy-900 text-orange-500">
                  <Eye className="h-5 w-5" />
                </div>
                <h3 className="mt-3 font-display text-lg font-bold text-navy-900">Our Vision</h3>
                <p className="mt-2 text-sm leading-relaxed text-navy-600">
                  Be India's leading truck dispatching and logistics training academy, recognized for industry-ready education.
                </p>
              </div>
            </div>

            {/* Key Features */}
            <div className="reveal reveal-delay-4 mt-8">
              <h3 className="font-display text-lg font-bold text-navy-900">Key Features</h3>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {KEY_FEATURES.map((f) => {
                  const Icon = iconMap[f.icon];
                  return (
                    <div key={f.title} className="flex items-center gap-3 rounded-xl bg-white p-3 shadow-sm ring-1 ring-navy-100">
                      <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-orange-100 text-orange-600">
                        <Icon className="h-4.5 w-4.5" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-navy-900">{f.title}</div>
                        <div className="text-xs text-navy-500">{f.desc}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
