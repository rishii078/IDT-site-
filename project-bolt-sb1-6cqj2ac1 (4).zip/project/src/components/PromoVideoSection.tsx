import { useCallback, useEffect, useRef, useState } from 'react';
import { Play, Pause, ChevronLeft, ChevronRight, MessageCircle, ArrowRight, Volume2, VolumeX, Clapperboard } from 'lucide-react';
import { PROMO_VIDEOS, type PromoVideo } from '@/data/media';
import { CONTACT } from '@/data';

export default function PromoVideoSection() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [isInView, setIsInView] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);

  const sectionRef = useRef<HTMLElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const activeVideo = PROMO_VIDEOS[activeIndex];

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = () => setReducedMotion(mq.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
      },
      { threshold: 0.4 }
    );

    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  const playVideo = useCallback(() => {
    const video = videoRef.current;
    if (!video || reducedMotion) return;
    video.play().then(() => setIsPlaying(true)).catch(() => {});
  }, [reducedMotion]);

  const pauseVideo = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    video.pause();
    setIsPlaying(false);
  }, []);

  useEffect(() => {
    if (!isInView) {
      pauseVideo();
      return;
    }
    if (!reducedMotion) {
      playVideo();
    }
  }, [isInView, reducedMotion, playVideo, pauseVideo, activeIndex]);

  const goToVideo = useCallback((index: number) => {
    setActiveIndex(index);
  }, []);

  const nextVideo = useCallback(() => {
    setActiveIndex((prev) => (prev + 1) % PROMO_VIDEOS.length);
  }, []);

  const prevVideo = useCallback(() => {
    setActiveIndex((prev) => (prev - 1 + PROMO_VIDEOS.length) % PROMO_VIDEOS.length);
  }, []);

  const handleVideoEnded = useCallback(() => {
    nextVideo();
  }, [nextVideo]);

  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      video.pause();
      setIsPlaying(false);
    }
  }, []);

  const toggleMute = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setIsMuted(video.muted);
  }, []);

  const whatsappText = encodeURIComponent("Hello IDT Campus, I'd like to know more about your training programs.");

  return (
    <section id="promo-videos" ref={sectionRef} className="relative overflow-hidden bg-navy-950 py-24">
      {/* Background decoration */}
      <div className="absolute -top-32 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-orange-500/5 blur-3xl" />
      <div className="absolute bottom-0 right-0 h-80 w-80 rounded-full bg-navy-700/20 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center">
          <div className="reveal inline-flex items-center gap-2 rounded-full bg-orange-500/20 px-4 py-2 text-sm font-semibold text-orange-400">
            <Clapperboard className="h-4 w-4" />
            Watch Us in Action
          </div>
          <h2 className="reveal reveal-delay-1 mt-5 font-display text-3xl font-extrabold text-white sm:text-4xl">
            IDT Campus Promotional Videos
          </h2>
          <p className="reveal reveal-delay-2 mx-auto mt-4 max-w-2xl text-base text-navy-300">
            Get a preview of our training programs, campus life, and practical dispatching sessions. Real videos will be added soon.
          </p>
        </div>

        {/* Main video player */}
        <div className="reveal mt-14">
          <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-navy-900 shadow-2xl">
            {/* Video / Poster area — 16:9 aspect */}
            <div className="relative aspect-video w-full bg-navy-900">
              {activeVideo.src ? (
                <video
                  ref={videoRef}
                  src={activeVideo.src}
                  poster={activeVideo.poster}
                  muted={isMuted}
                  loop={false}
                  playsInline
                  preload="metadata"
                  onEnded={handleVideoEnded}
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                  className="h-full w-full object-cover"
                />
              ) : (
                /* Placeholder poster — same 16:9 dimensions as the real video */
                <>
                  <img
                    src={activeVideo.poster}
                    alt={activeVideo.title}
                    className="h-full w-full object-cover"
                    loading="eager"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/30 to-navy-950/40" />
                </>
              )}

              {/* Branding overlay — subtle fade/slide animations */}
              <div className="pointer-events-none absolute inset-0 flex flex-col justify-end p-6 sm:p-10">
                <div
                  key={`overlay-${activeIndex}`}
                  className="animate-fade-in-up max-w-lg"
                  style={{ animationDelay: '0.1s', opacity: 0 }}
                >
                  <h3 className="font-display text-2xl font-extrabold text-white sm:text-3xl">
                    IDT CAMPUS
                  </h3>
                  <p className="mt-2 text-sm text-navy-200 sm:text-base">
                    Learn Truck Dispatching & Logistics Operations with Real-Time Practical Training
                  </p>
                  <div className="pointer-events-auto mt-5 flex flex-wrap gap-3">
                    <a
                      href="#courses"
                      className="flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition-all hover:bg-orange-600 active:scale-95"
                    >
                      Explore Courses
                      <ArrowRight className="h-4 w-4" />
                    </a>
                    <a
                      href={`https://wa.me/${CONTACT.phoneRaw}?text=${whatsappText}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 rounded-xl bg-white/10 px-5 py-2.5 text-sm font-bold text-white backdrop-blur-sm ring-1 ring-white/20 transition-all hover:bg-white/20 active:scale-95"
                    >
                      <MessageCircle className="h-4 w-4" />
                      WhatsApp Us
                    </a>
                  </div>
                </div>
              </div>

              {/* Video controls bar */}
              <div className="absolute bottom-0 left-0 right-0 flex items-center gap-3 bg-gradient-to-t from-navy-950/80 to-transparent px-4 py-3 sm:px-6">
                <button
                  onClick={togglePlay}
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur-sm transition-all hover:bg-white/20 active:scale-95"
                  aria-label={isPlaying ? 'Pause' : 'Play'}
                >
                  {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 translate-x-0.5" />}
                </button>
                <button
                  onClick={toggleMute}
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur-sm transition-all hover:bg-white/20 active:scale-95"
                  aria-label={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                </button>
                <div className="flex-1 text-sm font-medium text-white/80">
                  {activeVideo.title}
                </div>
                <span className="hidden text-xs font-semibold text-white/60 sm:block">{activeVideo.duration}</span>
                <div className="flex gap-1.5">
                  {PROMO_VIDEOS.map((v, i) => (
                    <button
                      key={v.id}
                      onClick={() => goToVideo(i)}
                      className={`h-1.5 rounded-full transition-all ${
                        i === activeIndex ? 'w-8 bg-orange-500' : 'w-3 bg-white/30 hover:bg-white/50'
                      }`}
                      aria-label={`Go to ${v.title}`}
                    />
                  ))}
                </div>
              </div>

              {/* Nav arrows on sides */}
              <button
                onClick={prevVideo}
                className="absolute left-3 top-1/2 -translate-y-1/2 flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur-sm transition-all hover:bg-white/20 active:scale-90"
                aria-label="Previous video"
              >
                <ChevronLeft className="h-6 w-6" />
              </button>
              <button
                onClick={nextVideo}
                className="absolute right-3 top-1/2 -translate-y-1/2 flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur-sm transition-all hover:bg-white/20 active:scale-90"
                aria-label="Next video"
              >
                <ChevronRight className="h-6 w-6" />
              </button>

              {/* Coming soon badge */}
              {!activeVideo.src && (
                <div className="absolute right-4 top-4 rounded-full bg-orange-500/90 px-4 py-1.5 text-xs font-bold text-white shadow-lg backdrop-blur-sm">
                  Promotional Video Coming Soon
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Video selection cards */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {PROMO_VIDEOS.map((video, i) => (
            <VideoCard
              key={video.id}
              video={video}
              isActive={i === activeIndex}
              onClick={() => goToVideo(i)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

function VideoCard({
  video,
  isActive,
  onClick,
}: {
  video: PromoVideo;
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`group relative overflow-hidden rounded-2xl text-left transition-all duration-300 ${
        isActive
          ? 'ring-2 ring-orange-500 shadow-xl shadow-orange-500/20'
          : 'ring-1 ring-white/10 hover:ring-white/30'
      }`}
    >
      {/* Thumbnail — same aspect ratio as final design */}
      <div className="relative aspect-video w-full overflow-hidden bg-navy-800">
        <img
          src={video.poster}
          alt={video.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/80 to-transparent" />

        {/* Play indicator */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className={`flex h-14 w-14 items-center justify-center rounded-full backdrop-blur-sm transition-all ${
            isActive ? 'bg-orange-500 text-white' : 'bg-white/20 text-white group-hover:bg-white/30'
          }`}>
            <Play className="h-6 w-6 translate-x-0.5" />
          </div>
        </div>

        {/* Duration badge */}
        <div className="absolute bottom-3 right-3 rounded-md bg-navy-950/80 px-2 py-0.5 text-xs font-semibold text-white">
          {video.duration}
        </div>

        {/* Active indicator */}
        {isActive && (
          <div className="absolute top-3 left-3 flex items-center gap-1.5 rounded-full bg-orange-500 px-3 py-1 text-xs font-bold text-white">
            <span className="flex h-2 w-2 items-center justify-center">
              <span className="h-1.5 w-1.5 animate-ping rounded-full bg-white" />
              <span className="absolute h-1.5 w-1.5 rounded-full bg-white" />
            </span>
            Now Playing
          </div>
        )}
      </div>

      {/* Card content */}
      <div className="bg-navy-900 p-4">
        <h4 className="font-display text-sm font-bold text-white">{video.title}</h4>
        <p className="mt-1.5 text-xs leading-relaxed text-navy-300">{video.description}</p>
      </div>
    </button>
  );
}
