import { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { FAQS } from '@/data';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="relative overflow-hidden bg-navy-50/30 py-24">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="reveal inline-flex items-center gap-2 rounded-full bg-orange-100 px-4 py-2 text-sm font-semibold text-orange-600">
            <HelpCircle className="h-4 w-4" />
            FAQ
          </div>
          <h2 className="reveal reveal-delay-1 mt-5 font-display text-3xl font-extrabold text-navy-900 sm:text-4xl">
            Frequently Asked Questions
          </h2>
          <p className="reveal reveal-delay-2 mt-4 text-base text-navy-600">
            Got questions? We've got answers. Find everything you need to know about our training programs.
          </p>
        </div>

        <div className="reveal reveal-delay-3 mt-12 space-y-4">
          {FAQS.map((faq, i) => {
            const isOpen = openIndex === i;
            return (
              <div
                key={i}
                className={`overflow-hidden rounded-2xl border transition-all ${
                  isOpen
                    ? 'border-orange-300 bg-white shadow-lg shadow-orange-500/5'
                    : 'border-navy-100 bg-white hover:border-navy-200'
                }`}
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
                  aria-expanded={isOpen}
                >
                  <span className="font-display text-base font-bold text-navy-900">{faq.q}</span>
                  <div className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg transition-all ${
                    isOpen ? 'bg-orange-500 text-white rotate-180' : 'bg-navy-100 text-navy-600'
                  }`}>
                    <ChevronDown className="h-5 w-5" />
                  </div>
                </button>
                <div
                  className="grid transition-all duration-300 ease-out"
                  style={{ gridTemplateRows: isOpen ? '1fr' : '0fr' }}
                >
                  <div className="overflow-hidden">
                    <p className="px-6 pb-5 text-sm leading-relaxed text-navy-600">{faq.a}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Still have questions */}
        <div className="reveal mt-12 rounded-2xl bg-navy-900 p-8 text-center">
          <h3 className="font-display text-xl font-bold text-white">Still have questions?</h3>
          <p className="mt-3 text-sm text-navy-200">Our team is here to help. Reach out and we'll guide you through everything.</p>
          <a
            href="#contact"
            className="mt-5 inline-flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition-all hover:bg-orange-600 active:scale-95"
          >
            Contact Us
          </a>
        </div>
      </div>
    </section>
  );
}
