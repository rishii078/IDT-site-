import { Clock, IndianRupee, CheckCircle2, ArrowRight, Zap, Star } from 'lucide-react';
import { COURSES, COMBO_PROGRAMS } from '@/data';
import { COURSE_IMAGES } from '@/data/media';

const courseImageMap = new Map(COURSE_IMAGES.map((c) => [c.title, c.image]));

export default function Courses() {
  return (
    <>
      {/* Individual Courses */}
      <section id="courses" className="relative overflow-hidden bg-navy-50/30 py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="reveal inline-flex items-center gap-2 rounded-full bg-orange-100 px-4 py-2 text-sm font-semibold text-orange-600">
              <Star className="h-4 w-4" />
              Our Courses
            </div>
            <h2 className="reveal reveal-delay-1 mt-5 font-display text-3xl font-extrabold text-navy-900 sm:text-4xl">
              Specialized Training Programs
            </h2>
            <p className="reveal reveal-delay-2 mx-auto mt-4 max-w-2xl text-base text-navy-600">
              Choose from our individual courses, each designed to give you practical expertise in a specific area of logistics and dispatching.
            </p>
          </div>

          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {COURSES.map((course, i) => (
              <div
                key={course.title}
                className={`reveal reveal-delay-${i + 1} card-lift group relative overflow-hidden rounded-2xl bg-white shadow-md ring-1 ring-navy-100`}
              >
                {/* Course image — replaceable via media.ts */}
                <div className="relative h-40 w-full overflow-hidden">
                  <img
                    src={courseImageMap.get(course.title)}
                    alt={course.title}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${course.color}`} />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-950/60 to-transparent" />
                  <div className={`absolute bottom-3 left-3 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${course.color} text-white shadow-lg`}>
                    <course.icon className="h-5 w-5" />
                  </div>
                </div>

                <div className="p-6">

                <h3 className="mt-5 font-display text-lg font-bold text-navy-900">{course.title}</h3>

                <div className="mt-3 flex items-center gap-4 text-sm">
                  <span className="flex items-center gap-1.5 font-semibold text-navy-700">
                    <Clock className="h-4 w-4 text-orange-500" />
                    {course.duration}
                  </span>
                  <span className="flex items-center gap-1.5 font-bold text-navy-900">
                    <IndianRupee className="h-4 w-4 text-orange-500" />
                    {course.fee.replace('₹', '')}
                  </span>
                </div>

                <div className="mt-5 border-t border-navy-100 pt-4">
                  <p className="text-xs font-bold uppercase tracking-wide text-navy-400">You'll Learn</p>
                  <ul className="mt-3 space-y-2">
                    {course.topics.map((topic) => (
                      <li key={topic} className="flex items-start gap-2 text-sm text-navy-600">
                        <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-orange-500" />
                        {topic}
                      </li>
                    ))}
                  </ul>
                </div>

                <a
                  href="#contact"
                  className="mt-6 flex items-center justify-center gap-2 rounded-xl bg-navy-900 py-3 text-sm font-bold text-white transition-all hover:bg-orange-500 group-hover:bg-orange-500"
                >
                  Enroll Now
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Combo Programs */}
      <section id="programs" className="relative overflow-hidden bg-navy-900 py-24">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/2 left-1/2 h-96 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full bg-orange-500 blur-3xl" />
        </div>

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="reveal inline-flex items-center gap-2 rounded-full bg-orange-500/20 px-4 py-2 text-sm font-semibold text-orange-400">
              <Zap className="h-4 w-4" />
              Combo Programs
            </div>
            <h2 className="reveal reveal-delay-1 mt-5 font-display text-3xl font-extrabold text-white sm:text-4xl">
              Save More with Combo Packages
            </h2>
            <p className="reveal reveal-delay-2 mx-auto mt-4 max-w-2xl text-base text-navy-200">
              Get comprehensive training by bundling multiple courses together at a reduced fee. Perfect for those who want complete logistics expertise.
            </p>
          </div>

          <div className="mx-auto mt-14 grid max-w-5xl gap-8 lg:grid-cols-2">
            {COMBO_PROGRAMS.map((program, i) => (
              <div
                key={program.title}
                className={`reveal reveal-delay-${i + 1} relative overflow-hidden rounded-3xl ${
                  program.featured
                    ? 'bg-gradient-to-br from-orange-500 to-orange-600 text-white shadow-2xl shadow-orange-500/30 lg:scale-105'
                    : 'bg-white/5 border border-white/10 text-white backdrop-blur-md'
                }`}
              >
                {/* Combo program image — replaceable via media.ts */}
                <div className="relative h-44 w-full overflow-hidden rounded-t-3xl">
                  <img
                    src={courseImageMap.get(program.title)}
                    alt={program.title}
                    className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
                    loading="lazy"
                  />
                  <div className={`absolute inset-0 ${program.featured ? 'bg-gradient-to-t from-orange-600/90 to-orange-500/30' : 'bg-gradient-to-t from-navy-900/90 to-navy-900/30'}`} />
                </div>

                <div className="p-8">
                {program.badge && (
                  <div className={`absolute top-6 right-6 rounded-full px-3 py-1 text-xs font-bold ${
                    program.featured ? 'bg-white text-orange-600' : 'bg-orange-500 text-white'
                  }`}>
                    {program.badge}
                  </div>
                )}

                <div className={`flex h-14 w-14 items-center justify-center rounded-2xl ${
                  program.featured ? 'bg-white/20' : 'bg-orange-500/20'
                }`}>
                  <Zap className={`h-7 w-7 ${program.featured ? 'text-white' : 'text-orange-400'}`} />
                </div>

                <h3 className="mt-5 font-display text-xl font-bold leading-tight">{program.title}</h3>

                <div className="mt-4 flex items-center gap-6">
                  <div>
                    <div className={`text-xs ${program.featured ? 'text-white/70' : 'text-navy-300'}`}>Duration</div>
                    <div className="font-display text-2xl font-extrabold">{program.duration}</div>
                  </div>
                  <div className={`h-10 w-px ${program.featured ? 'bg-white/20' : 'bg-white/10'}`} />
                  <div>
                    <div className={`text-xs ${program.featured ? 'text-white/70' : 'text-navy-300'}`}>Total Fee</div>
                    <div className="font-display text-2xl font-extrabold">{program.fee}</div>
                  </div>
                </div>

                <p className={`mt-5 text-sm ${program.featured ? 'text-white/90' : 'text-navy-200'}`}>{program.description}</p>

                <div className={`mt-6 border-t pt-5 ${program.featured ? 'border-white/20' : 'border-white/10'}`}>
                  <p className={`text-xs font-bold uppercase tracking-wide ${program.featured ? 'text-white/70' : 'text-navy-300'}`}>Program Includes</p>
                  <ul className="mt-3 space-y-2.5">
                    {program.includes.map((item) => (
                      <li key={item} className="flex items-start gap-2.5 text-sm">
                        <CheckCircle2 className={`mt-0.5 h-4 w-4 flex-shrink-0 ${program.featured ? 'text-white' : 'text-orange-400'}`} />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <a
                  href="#contact"
                  className={`mt-7 flex items-center justify-center gap-2 rounded-xl py-3.5 text-sm font-bold transition-all hover:scale-[1.02] ${
                    program.featured
                      ? 'bg-white text-orange-600 hover:bg-navy-900 hover:text-white'
                      : 'bg-orange-500 text-white hover:bg-orange-600'
                  }`}
                >
                  Enroll in this Program
                  <ArrowRight className="h-4 w-4" />
                </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
