/*
 * ============================================================================
 * IDT CAMPUS — CENTRALIZED MEDIA CONFIGURATION
 * ============================================================================
 *
 * This is the SINGLE SOURCE OF TRUTH for all photos and videos on the website.
 *
 * HOW TO REPLACE PLACEHOLDERS WITH REAL MEDIA:
 *
 * VIDEOS:
 *   Replace the `src` field in PROMO_VIDEOS with your real video file path.
 *   Example: src: '/media/videos/video1.mp4'
 *   Place the file in: public/media/videos/video1.mp4
 *   Also update the `poster` field with the matching thumbnail.
 *
 * PHOTOS:
 *   Replace the `image` field in GALLERY_IMAGES with your real photo URL.
 *   Example: image: '/media/images/classroom-1.jpg'
 *   Place the file in: public/media/images/classroom-1.jpg
 *
 * COURSE IMAGES:
 *   Each course in COURSE_IMAGES maps by title to the courses in data.ts.
 *   Replace the `image` field with your real course photo.
 *
 * LOGO:
 *   Replace the `src` field in LOGO_MEDIA with your final logo file.
 *
 * No component, layout, or styling changes are needed when swapping media.
 * The website will automatically display the new content.
 *
 * When a backend is added later, this file can be replaced with an API call
 * that returns the same data structure.
 * ============================================================================
 */

export type PromoVideo = {
  id: string;
  title: string;
  description: string;
  src: string;
  poster: string;
  duration: string;
};

export type GalleryImage = {
  id: string;
  title: string;
  category: GalleryCategory;
  image: string;
  aspect: 'wide' | 'square' | 'tall';
};

export type GalleryCategory =
  | 'Academy'
  | 'Classroom'
  | 'Truck Dispatching'
  | 'Practical Training'
  | 'Students'
  | 'Logistics'
  | 'Software Training';

export type CourseImage = {
  title: string;
  image: string;
};

export const LOGO_MEDIA = {
  src: '/WhatsApp_Image_2026-10-05_at_02.38.04.jpeg',
  alt: 'IDT Campus — Institute of Dispatch & Logistics Training',
};

export const HERO_MEDIA = {
  backgroundImage: '/WhatsApp_Image_2026-10-05_at_02.38.04.jpeg',
  cardLogo: '/WhatsApp_Image_2026-10-05_at_02.38.04.jpeg',
};

export const PROMO_VIDEOS: PromoVideo[] = [
  {
    id: 'video-1',
    title: 'IDT Campus Introduction',
    description: 'Discover our academy, mission, and the career opportunities in truck dispatching and logistics.',
    src: '',
    poster: 'https://images.pexels.com/photos/28264496/pexels-photo-28264496.jpeg?auto=compress&cs=tinysrgb&w=1280&h=720',
    duration: '2:30',
  },
  {
    id: 'video-2',
    title: 'Truck Dispatching Training',
    description: 'Step inside our hands-on dispatch training — live load booking, carrier setup, and route planning.',
    src: '',
    poster: 'https://images.pexels.com/photos/6170100/pexels-photo-6170100.jpeg?auto=compress&cs=tinysrgb&w=1280&h=720',
    duration: '3:15',
  },
  {
    id: 'video-3',
    title: 'Practical Logistics Training',
    description: 'Real-world logistics operations — freight management, compliance, and industry software in action.',
    src: '',
    poster: 'https://images.pexels.com/photos/1797428/pexels-photo-1797428.jpeg?auto=compress&cs=tinysrgb&w=1280&h=720',
    duration: '2:45',
  },
];

export const GALLERY_CATEGORIES: GalleryCategory[] = [
  'Academy',
  'Classroom',
  'Truck Dispatching',
  'Practical Training',
  'Students',
  'Logistics',
  'Software Training',
];

export const GALLERY_IMAGES: GalleryImage[] = [
  {
    id: 'g-1',
    title: 'Campus Overview',
    category: 'Academy',
    image: 'https://images.pexels.com/photos/8353774/pexels-photo-8353774.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'wide',
  },
  {
    id: 'g-2',
    title: 'Classroom Training Session',
    category: 'Classroom',
    image: 'https://images.pexels.com/photos/5530484/pexels-photo-5530484.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'wide',
  },
  {
    id: 'g-3',
    title: 'Live Dispatch Operations',
    category: 'Truck Dispatching',
    image: 'https://images.pexels.com/photos/6170100/pexels-photo-6170100.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'square',
  },
  {
    id: 'g-4',
    title: 'Hands-On Practical Training',
    category: 'Practical Training',
    image: 'https://images.pexels.com/photos/32394664/pexels-photo-32394664.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'square',
  },
  {
    id: 'g-5',
    title: 'Student Computer Lab',
    category: 'Students',
    image: 'https://images.pexels.com/photos/5530515/pexels-photo-5530515.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'wide',
  },
  {
    id: 'g-6',
    title: 'Warehouse & Freight Logistics',
    category: 'Logistics',
    image: 'https://images.pexels.com/photos/1797428/pexels-photo-1797428.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'wide',
  },
  {
    id: 'g-7',
    title: 'Software Training Workstations',
    category: 'Software Training',
    image: 'https://images.pexels.com/photos/8353774/pexels-photo-8353774.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'square',
  },
  {
    id: 'g-8',
    title: 'Group Learning Session',
    category: 'Classroom',
    image: 'https://images.pexels.com/photos/5530442/pexels-photo-5530442.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'wide',
  },
  {
    id: 'g-9',
    title: 'Freight Operations Training',
    category: 'Truck Dispatching',
    image: 'https://images.pexels.com/photos/6170183/pexels-photo-6170183.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'square',
  },
  {
    id: 'g-10',
    title: 'Practical Dispatch Exercise',
    category: 'Practical Training',
    image: 'https://images.pexels.com/photos/256219/pexels-photo-256219.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'wide',
  },
  {
    id: 'g-11',
    title: 'Cargo & Supply Chain',
    category: 'Logistics',
    image: 'https://images.pexels.com/photos/262353/pexels-photo-262353.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'wide',
  },
  {
    id: 'g-12',
    title: 'Student Practice Session',
    category: 'Students',
    image: 'https://images.pexels.com/photos/5530482/pexels-photo-5530482.jpeg?auto=compress&cs=tinysrgb&w=940&h=650',
    aspect: 'square',
  },
];

export const COURSE_IMAGES: CourseImage[] = [
  {
    title: 'Truck Dispatching',
    image: 'https://images.pexels.com/photos/6170100/pexels-photo-6170100.jpeg?auto=compress&cs=tinysrgb&w=600&h=400',
  },
  {
    title: 'Freight Brokerage',
    image: 'https://images.pexels.com/photos/28264496/pexels-photo-28264496.jpeg?auto=compress&cs=tinysrgb&w=600&h=400',
  },
  {
    title: 'Dispatch Accounting',
    image: 'https://images.pexels.com/photos/8353774/pexels-photo-8353774.jpeg?auto=compress&cs=tinysrgb&w=600&h=400',
  },
  {
    title: 'Driver/Truck Safety & Compliance',
    image: 'https://images.pexels.com/photos/6563903/pexels-photo-6563903.jpeg?auto=compress&cs=tinysrgb&w=600&h=400',
  },
  {
    title: 'Truck Dispatching Professional Program',
    image: 'https://images.pexels.com/photos/34902065/pexels-photo-34902065.jpeg?auto=compress&cs=tinysrgb&w=600&h=400',
  },
  {
    title: 'Advance Dispatching Master Program',
    image: 'https://images.pexels.com/photos/11087837/pexels-photo-11087837.jpeg?auto=compress&cs=tinysrgb&w=600&h=400',
  },
];
