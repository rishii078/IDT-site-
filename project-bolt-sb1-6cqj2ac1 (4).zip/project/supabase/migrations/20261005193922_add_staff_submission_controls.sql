/*
# Add staff controls for contact submissions

1. Modified Tables
- `contact_submissions`
  - Add `status` (text, default `new`) so staff can track each inquiry.
  - Add `updated_at` (timestamptz, default now()) for dashboard timestamps.

2. Security
- Keep public visitors limited to creating contact submissions.
- Allow only the authorized IDT Campus staff email to read, update, or delete submissions after signing in.
- Keep separate policies for SELECT, INSERT, UPDATE, and DELETE.

3. Important Notes
- The staff dashboard uses Supabase email/password authentication.
- The authorized staff account is `dispatch@idtcampus.in`.
- Student submissions remain private from anonymous website visitors.
*/

ALTER TABLE contact_submissions
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'new';

ALTER TABLE contact_submissions
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

ALTER TABLE contact_submissions
  DROP CONSTRAINT IF EXISTS contact_submissions_status_check;

ALTER TABLE contact_submissions
  ADD CONSTRAINT contact_submissions_status_check
  CHECK (status IN ('new', 'contacted', 'enrolled', 'closed'));

CREATE INDEX IF NOT EXISTS contact_submissions_submitted_at_idx
  ON contact_submissions (submitted_at DESC);

DROP POLICY IF EXISTS "staff_select_contact" ON contact_submissions;
CREATE POLICY "staff_select_contact"
ON contact_submissions FOR SELECT
TO authenticated
USING (lower(coalesce(auth.jwt() ->> 'email', '')) = 'dispatch@idtcampus.in');

DROP POLICY IF EXISTS "staff_update_contact" ON contact_submissions;
CREATE POLICY "staff_update_contact"
ON contact_submissions FOR UPDATE
TO authenticated
USING (lower(coalesce(auth.jwt() ->> 'email', '')) = 'dispatch@idtcampus.in')
WITH CHECK (lower(coalesce(auth.jwt() ->> 'email', '')) = 'dispatch@idtcampus.in');

DROP POLICY IF EXISTS "staff_delete_contact" ON contact_submissions;
CREATE POLICY "staff_delete_contact"
ON contact_submissions FOR DELETE
TO authenticated
USING (lower(coalesce(auth.jwt() ->> 'email', '')) = 'dispatch@idtcampus.in');

DROP POLICY IF EXISTS "staff_insert_contact" ON contact_submissions;
CREATE POLICY "staff_insert_contact"
ON contact_submissions FOR INSERT
TO authenticated
WITH CHECK (lower(coalesce(auth.jwt() ->> 'email', '')) = 'dispatch@idtcampus.in');