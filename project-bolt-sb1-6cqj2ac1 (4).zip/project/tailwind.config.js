/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        display: ['Plus Jakarta Sans', 'sans-serif'],
      },
      colors: {
        navy: {
          50: '#eef2f9',
          100: '#d4ddf0',
          200: '#a8bce0',
          300: '#7c9bd0',
          400: '#507ac0',
          500: '#38599a',
          600: '#2b4677',
          700: '#1e3354',
          800: '#14223b',
          900: '#0b1f3a',
          950: '#061327',
        },
        brand: {
          orange: '#f97316',
          'orange-dark': '#ea580c',
        },
      },
      animation: {
        'fade-in-up': 'fadeInUp 0.7s ease-out forwards',
        'fade-in': 'fadeIn 0.8s ease-out forwards',
        'slide-in-left': 'slideInLeft 0.7s ease-out forwards',
        'slide-in-right': 'slideInRight 0.7s ease-out forwards',
        'scale-in': 'scaleIn 0.5s ease-out forwards',
        'float': 'floatY 3s ease-in-out infinite',
        'pulse-glow': 'pulseGlow 2.5s ease-in-out infinite',
        'marquee': 'marquee 20s linear infinite',
      },
    },
  },
  plugins: [],
};
